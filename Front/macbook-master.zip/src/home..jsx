import React from 'react';
import { Switch, Route } from 'react-router-dom';
import Home from './Home';

function Home() {
  return (
    <div>
      <h1>Página Inicial</h1>
      {/* Conteúdo da página inicial */}
    </div>
  );
}

function App() {
  return (
    <div>
      {/* Outros componentes da sua aplicação */}
      <Switch>
        <Route exact path="/" component={Home} />
        {/* Outras rotas */}
      </Switch>
    </div>
  );
}


export default Home;
